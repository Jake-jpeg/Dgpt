// DivorceGPT General Form Filler API
// Route: /api/forms/chat
// This is the GENERAL engine. State-specific AI instructions live in /lib/states/{code}.ts
// This route defaults to NY for backwards compatibility.
// New states use /api/forms/chat/[state]/route.ts which shares this same architecture.

import Anthropic from '@anthropic-ai/sdk';
import { NextResponse } from 'next/server';
import { getStateConfig } from '@/lib/states';
import { ANTHROPIC_MODEL } from '@/lib/ai-config';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// ═══════════════════════════════════════════════════════════════
// GUARDRAIL 02: THE BLACKHOLE — Server-side sensitive data redaction
// Strips SSNs, bank accounts, credit cards, and other PII from
// user messages BEFORE they are sent to the AI provider.
// Reference: divorcegpt.com/transparency — "Sensitive Data Gets Destroyed in Transit"
// ═══════════════════════════════════════════════════════════════
const SENSITIVE_PATTERNS = [
  // SSN formats: XXX-XX-XXXX, XXX XX XXXX, XXXXXXXXX
  /\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b/g,
  // Credit card: 13-19 digit sequences with optional separators
  /\b(?:\d[-\s]?){13,19}\b/g,
  // Bank account: 8-17 digit sequences preceded by account-related keywords
  /(?:account|acct|routing|aba)[\s#:]*\d{8,17}/gi,
  // Driver's license: state abbreviation + number patterns
  /\b(?:DL|driver'?s?\s*(?:license|lic))[\s#:]*[A-Z0-9-]{6,15}/gi,
];

function redactSensitiveData(text: string): { redacted: string; wasRedacted: boolean } {
  let redacted = text;
  let wasRedacted = false;

  for (const pattern of SENSITIVE_PATTERNS) {
    const newText = redacted.replace(pattern, '[REDACTED]');
    if (newText !== redacted) {
      wasRedacted = true;
      redacted = newText;
    }
  }

  return { redacted, wasRedacted };
}

// ═══════════════════════════════════════════════════════════════
// Helper: Parse date string to Date object
// ═══════════════════════════════════════════════════════════════
function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  const parsed = new Date(dateStr);
  if (!isNaN(parsed.getTime())) return parsed;
  const match = dateStr.match(/(\w+)\s+(\d{1,2}),?\s*(\d{4})/);
  if (match) {
    const monthNames = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    const monthIndex = monthNames.indexOf(match[1].toLowerCase());
    if (monthIndex !== -1) {
      return new Date(parseInt(match[3]), monthIndex, parseInt(match[2]));
    }
  }
  return null;
}

// ═══════════════════════════════════════════════════════════════
// Helper: Check if date is at least N months ago from a canonical date
// FIX #3: Uses a single canonical date passed in, not new Date()
// ═══════════════════════════════════════════════════════════════
function isAtLeastMonthsAgo(date: Date, months: number, canonicalNow: Date): boolean {
  const threshold = new Date(canonicalNow.getFullYear(), canonicalNow.getMonth() - months, canonicalNow.getDate());
  return date <= threshold;
}

export async function POST(req: Request) {
  try {
    const { messages, currentPhase, phase1Data, phase2Data, phase3Data, stateCode } = await req.json();

    // Default to NY for backwards compatibility
    const resolvedState = stateCode || 'ny';
    const stateConfig = getStateConfig(resolvedState);
    if (!stateConfig) {
      return NextResponse.json(
        { reply: `State "${resolvedState}" is not yet supported. Check back soon.`, extractedData: null },
        { status: 404 }
      );
    }

    // Extract field keys from state config
    const p1Keys = stateConfig.phase1Fields.map(f => f.key);
    const p2Keys = stateConfig.phase2Fields.map(f => f.key);
    const p3Keys = stateConfig.phase3Fields.map(f => f.key);

    // ═══════════════════════════════════════════════════════════════
    // FIX #1: Server-side redaction BEFORE sending to Anthropic
    // Reference: Transparency post Guardrail 02
    // "At the architectural level, DivorceGPT retains no chat data"
    // ═══════════════════════════════════════════════════════════════
    let sensitiveDataDetected = false;
    const sanitizedMessages = messages.map((msg: { role: string; content: string }) => {
      if (msg.role === 'user') {
        const { redacted, wasRedacted } = redactSensitiveData(msg.content);
        if (wasRedacted) sensitiveDataDetected = true;
        return { ...msg, content: redacted };
      }
      return msg;
    });

    // ═══════════════════════════════════════════════════════════════
    // FIX #2 & #3: Single canonical date for both AI and server validation
    // Reference: Transparency post Guardrail 05
    // "calculated from today's actual date, not the AI's training data"
    // ═══════════════════════════════════════════════════════════════
    const canonicalNow = new Date();
    const canonicalDateStr = canonicalNow.toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric'
    });

    // Build context based on current phase
    let contextMessage = '\n\n[SYSTEM STATUS: ';
    contextMessage += `Today's date: ${canonicalDateStr}. `;
    contextMessage += `Current Phase: ${currentPhase || 1}. `;
    contextMessage += `State: ${stateConfig.name}. `;

    if (phase1Data && Object.keys(phase1Data).length > 0) {
      contextMessage += `Phase 1 Data: ${JSON.stringify(phase1Data)}. `;
    }

    if (currentPhase === 1) {
      const missing = p1Keys.filter(f => !phase1Data?.[f]);
      if (missing.length > 0) {
        contextMessage += `Phase 1 missing: ${missing.join(', ')}. `;
      } else {
        contextMessage += 'Phase 1 COMPLETE - output {"phase1Complete": true}. ';
      }
    }

    if (currentPhase === 2) {
      contextMessage += `Phase 2 Data: ${JSON.stringify(phase2Data || {})}. `;
      const isReligious = phase1Data?.ceremonyType === 'religious';
      const missing = p2Keys.filter(f => !phase2Data?.[f]);
      if (missing.length > 0) {
        contextMessage += `Phase 2 missing: ${missing.join(', ')}. `;
      } else {
        contextMessage += 'Phase 2 COMPLETE - output {"phase2Complete": true}. ';
      }
      if (isReligious) {
        contextMessage += 'RELIGIOUS CEREMONY - waiver requirements apply per state law. ';
      }
    }

    if (currentPhase === 3) {
      contextMessage += `Phase 3 Data: ${JSON.stringify(phase3Data || {})}. `;
      const missing = p3Keys.filter(f => !phase3Data?.[f]);
      if (missing.length > 0) {
        contextMessage += `Phase 3 missing: ${missing.join(', ')}. `;
      } else {
        contextMessage += 'Phase 3 COMPLETE - output {"phase3Complete": true}. ';
      }
    }

    contextMessage += ']';

    // ═══════════════════════════════════════════════════════════════
    // PROMPT CACHING:
    //
    // EXPLICIT breakpoint on systemPrompt (~14K tokens for NY):
    //   Cached across ALL calls for this state. Written once on the
    //   first call, then read at 10% cost ($0.30/MTok vs $3/MTok)
    //   for every subsequent call within the 5-min TTL window.
    //
    // contextMessage changes every call (phase data, missing fields),
    // so it sits AFTER the cache breakpoint and is always fresh.
    // ═══════════════════════════════════════════════════════════════
    const response = await anthropic.messages.create({
      model: ANTHROPIC_MODEL,
      max_tokens: 1500,
      system: [
        {
          type: 'text',
          text: stateConfig.systemPrompt,
          cache_control: { type: 'ephemeral' },
        },
        {
          type: 'text',
          text: contextMessage,
        },
      ],
      messages: sanitizedMessages,
    });

    // ═══════════════════════════════════════════════════════════════
    // CACHE PERFORMANCE LOGGING
    // ═══════════════════════════════════════════════════════════════
    const usage = response.usage as {
      input_tokens: number;
      output_tokens: number;
      cache_creation_input_tokens?: number;
      cache_read_input_tokens?: number;
    };
    const cacheRead = usage.cache_read_input_tokens ?? 0;
    const cacheWrite = usage.cache_creation_input_tokens ?? 0;
    const uncached = usage.input_tokens;
    const totalInput = cacheRead + cacheWrite + uncached;
    const savingsPercent = totalInput > 0 ? Math.round((cacheRead / totalInput) * 100) : 0;
    console.log(
      `[Cache ${resolvedState.toUpperCase()}] read=${cacheRead} write=${cacheWrite} uncached=${uncached} output=${usage.output_tokens} | ${savingsPercent}% cached`
    );

    // ═══════════════════════════════════════════════════════════════
    // FIX #5: Join ALL content blocks, not just content[0]
    // ═══════════════════════════════════════════════════════════════
    const reply = response.content
      .filter(block => block.type === 'text')
      .map(block => block.type === 'text' ? block.text : '')
      .join('\n');

    // ═══════════════════════════════════════════════════════════════
    // GUARDRAIL 02b: Language-aware sensitive data notice
    // The AI responds in the user's language, so server-side notices
    // must also match. Detects language from recent user messages.
    // ═══════════════════════════════════════════════════════════════
    let finalReply = reply;
    if (sensitiveDataDetected) {
      // Detect conversation language from the last user message
      const lastUserMsg = [...messages].reverse().find((m: { role: string; content: string }) => m.role === 'user')?.content || '';
      const SENSITIVE_NOTICES: Record<string, string> = {
        zh: '我注意到您输入了敏感信息（如社会安全号码）。DivorceGPT 不需要、不存储、也不处理此类数据。请不要输入社会安全号码、银行账号或其他敏感标识符。如果您需要在法庭表格中填写社会安全号码，请在打印文件后自行填写。',
        ko: '민감한 정보(예: 사회보장번호)가 포함된 것을 발견했습니다. DivorceGPT는 이러한 데이터를 필요로 하지 않으며, 저장하거나 처리하지 않습니다. SSN, 은행 계좌 또는 기타 민감한 식별 정보를 입력하지 마세요. 법원 양식에 SSN을 기재해야 하는 경우, 출력된 문서에 직접 작성하세요.',
        es: 'He notado que incluyó información sensible como un número de Seguro Social. DivorceGPT no necesita, almacena ni procesa estos datos. Por favor no ingrese números de Seguro Social, cuentas bancarias u otros identificadores sensibles. Si necesita incluir un SSN en un formulario judicial, lo hará usted mismo en el documento impreso.',
        fr: 'J\'ai remarqué que vous avez inclus des informations sensibles comme un numéro de sécurité sociale. DivorceGPT n\'a pas besoin de ces données, ne les stocke pas et ne les traite pas. Veuillez ne pas saisir de numéros de sécurité sociale, de comptes bancaires ou d\'autres identifiants sensibles. Si vous devez inclure un SSN sur un formulaire judiciaire, vous le ferez vous-même sur le document imprimé.',
        pt: 'Percebi que você incluiu informações sensíveis como um número de Seguro Social. O DivorceGPT não precisa, não armazena e não processa esses dados. Por favor, não insira números de Seguro Social, contas bancárias ou outros identificadores sensíveis. Se precisar incluir um SSN em um formulário judicial, você fará isso no documento impresso.',
        ja: '社会保障番号などの機密情報が含まれていることに気づきました。DivorceGPTはこのようなデータを必要とせず、保存も処理もしません。SSN、銀行口座、その他の機密識別情報を入力しないでください。裁判所の書式にSSNを記入する必要がある場合は、印刷した書類にご自身で記入してください。',
        hi: 'मैंने देखा कि आपने सामाजिक सुरक्षा नंबर जैसी संवेदनशील जानकारी शामिल की है। DivorceGPT को इस डेटा की आवश्यकता नहीं है, न ही यह इसे संग्रहीत या संसाधित करता है। कृपया SSN, बैंक खाते या अन्य संवेदनशील पहचानकर्ता दर्ज न करें। यदि आपको अदालती फॉर्म पर SSN शामिल करने की आवश्यकता है, तो आप इसे मुद्रित दस्तावेज़ पर स्वयं करेंगे।',
        ar: 'لاحظت أنك قمت بتضمين معلومات حساسة مثل رقم الضمان الاجتماعي. DivorceGPT لا يحتاج هذه البيانات ولا يخزنها ولا يعالجها. يرجى عدم إدخال أرقام الضمان الاجتماعي أو الحسابات المصرفية أو المعرفات الحساسة الأخرى. إذا كنت بحاجة إلى تضمين رقم الضمان الاجتماعي في نموذج المحكمة، فستقوم بذلك بنفسك على المستند المطبوع.',
        it: 'Ho notato che hai incluso informazioni sensibili come un numero di previdenza sociale. DivorceGPT non ha bisogno, non memorizza e non elabora questi dati. Si prega di non inserire numeri di previdenza sociale, conti bancari o altri identificativi sensibili. Se devi includere un SSN in un modulo giudiziario, lo farai tu stesso sul documento stampato.',
        de: 'Mir ist aufgefallen, dass Sie sensible Informationen wie eine Sozialversicherungsnummer eingegeben haben. DivorceGPT benötigt diese Daten nicht, speichert sie nicht und verarbeitet sie nicht. Bitte geben Sie keine Sozialversicherungsnummern, Bankkontonummern oder andere sensible Kennungen ein. Wenn Sie eine SSN auf einem Gerichtsformular angeben müssen, tun Sie dies selbst auf dem ausgedruckten Dokument.',
        id: 'Saya melihat Anda memasukkan informasi sensitif seperti nomor Jaminan Sosial. DivorceGPT tidak memerlukan, menyimpan, atau memproses data ini. Mohon jangan masukkan SSN, rekening bank, atau pengenal sensitif lainnya. Jika Anda perlu mencantumkan SSN pada formulir pengadilan, Anda akan melakukannya sendiri pada dokumen yang dicetak.',
      };
      // Simple language detection: check for CJK, Korean, Arabic, Hindi, etc.
      const langDetect = (text: string): string => {
        if (/[\u4e00-\u9fff]/.test(text)) return 'zh';
        if (/[\uac00-\ud7af]/.test(text)) return 'ko';
        if (/[\u0600-\u06ff]/.test(text)) return 'ar';
        if (/[\u0900-\u097f]/.test(text)) return 'hi';
        if (/[\u3040-\u30ff\u31f0-\u31ff]/.test(text)) return 'ja';
        // Latin-script languages: check for common markers
        if (/(?:^|\s)(?:el|la|los|las|una|por|como|que|está|tiene|puede)\b/i.test(text)) return 'es';
        if (/(?:^|\s)(?:le|la|les|des|une|est|pour|avec|dans|qui|que|pas|vous|nous|je)\b/i.test(text)) return 'fr';
        if (/(?:^|\s)(?:o|os|uma|para|como|está|tem|pode|você|não|eu|meu)\b/i.test(text)) return 'pt';
        if (/(?:^|\s)(?:il|lo|gli|una|per|che|con|sono|della|questo)\b/i.test(text)) return 'it';
        if (/(?:^|\s)(?:der|die|das|ein|eine|und|ist|für|mit|ich|nicht)\b/i.test(text)) return 'de';
        if (/(?:^|\s)(?:saya|anda|yang|dan|untuk|dengan|ini|itu|akan|dari)\b/i.test(text)) return 'id';
        return 'en';
      };
      const detectedLang = langDetect(lastUserMsg);
      const notice = SENSITIVE_NOTICES[detectedLang] ||
        'I noticed you included sensitive information like a Social Security number. DivorceGPT does not need, store, or process this data. Please do not enter SSNs, bank accounts, or other sensitive identifiers. If you need to include an SSN on a court form, you will do that yourself on the printed document.';
      finalReply = notice + '\n\n' + reply;
    }

    // Parse JSON blocks
    const jsonMatches = [...reply.matchAll(/```json\s*([\s\S]*?)\s*```/g)];
    let extractedData: Record<string, string | boolean> = {};
    let phase1Complete = false;
    let phase2Complete = false;
    let phase3Complete = false;
    let isDisqualified = false;
    let disqualifyReason = '';
    let isTerminated = false;
    let terminateReason = '';

    // ═══════════════════════════════════════════════════════════════
    // FIX #4: Collect ALL validation warnings, not just the last one
    // ═══════════════════════════════════════════════════════════════
    const validationWarnings: string[] = [];

    for (const match of jsonMatches) {
      try {
        const parsed = JSON.parse(match[1]);

        if (parsed.phase1Complete) phase1Complete = true;
        if (parsed.phase2Complete) phase2Complete = true;
        if (parsed.phase3Complete) phase3Complete = true;

        if (parsed.disqualified) {
          isDisqualified = true;
          disqualifyReason = parsed.reason || '';
        }

        if (parsed.terminate) {
          isTerminated = true;
          terminateReason = parsed.reason || 'policy_violation';
        }

        if (parsed.field && parsed.value !== undefined) {
          const field = parsed.field;
          const value = parsed.value;

          // ═══════════════════════════════════════════════════════
          // GUARDRAIL 05: SERVER-SIDE VALIDATION — The Safety Net
          // Reference: Transparency post Guardrail 05
          // "None of this relies on the AI being correct"
          // ═══════════════════════════════════════════════════════

          // NAME VALIDATION
          if (['plaintiffName', 'defendantName', 'firstSpouseName', 'secondSpouseName', 'witnessName'].includes(field)) {
            if (value.trim().length < 3) {
              validationWarnings.push(`Please provide a full legal name (first and last name).`);
              continue;
            }
            if (!/\s/.test(value.trim())) {
              validationWarnings.push(`Please provide both first and last name.`);
              continue;
            }
            if (/\d/.test(value)) {
              validationWarnings.push(`Name should not contain numbers. Please re-enter your legal name.`);
              continue;
            }
            extractedData[field] = value;
            continue;
          }

          // ADDRESS VALIDATION
          if (['qualifyingAddress', 'plaintiffAddress', 'defendantAddress', 'defendantCurrentAddress'].includes(field)) {
            const hasZip = /\d{5}(-\d{4})?/.test(value);
            if (!hasZip) {
              validationWarnings.push(`Address must include a ZIP code. Please re-enter the complete address.`);
              continue;
            }
            const statePattern = /\b(AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|DC|Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New\s+Hampshire|New\s+Jersey|New\s+Mexico|New\s+York|North\s+Carolina|North\s+Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode\s+Island|South\s+Carolina|South\s+Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West\s+Virginia|Wisconsin|Wyoming)\b/i;
            if (!statePattern.test(value)) {
              validationWarnings.push(`Address must include a state. Please provide the full address (street, city, state, ZIP).`);
              continue;
            }
            if (value.trim().length < 15) {
              validationWarnings.push(`Address appears incomplete. Please provide the full street address, city, state, and ZIP code.`);
              continue;
            }
            if (!/\d/.test(value.split(',')[0] || value)) {
              validationWarnings.push(`Address should include a street number. Please verify.`);
              continue;
            }

            // ═══════════════════════════════════════════════════════
            // FIX #6: Server-side address/county mismatch enforcement
            // Reference: Transparency post Guardrail 05
            // "cross-checks the user's filing county against their address"
            // ═══════════════════════════════════════════════════════
            if (field === 'qualifyingAddress' || field === 'plaintiffAddress') {
              const currentCounty = phase1Data?.qualifyingCounty || extractedData['qualifyingCounty'];
              if (currentCounty && resolvedState === 'ny') {
                const boroughMap: Record<string, string[]> = {
                  'bronx': ['bronx'],
                  'kings': ['brooklyn', 'kings'],
                  'new york': ['manhattan', 'new york'],
                  'queens': ['queens'],
                  'richmond': ['staten island', 'richmond'],
                };
                const countyLower = (currentCounty as string).toLowerCase();
                const addressLower = value.toLowerCase();
                const countyAliases = boroughMap[countyLower] || [countyLower];
                const addressHasCounty = countyAliases.some(alias => addressLower.includes(alias));
                const allKnownAreas = Object.values(boroughMap).flat();
                const addressMentionsOtherArea = allKnownAreas.some(area =>
                  addressLower.includes(area) && !countyAliases.includes(area)
                );
                if (addressMentionsOtherArea && !addressHasCounty) {
                  validationWarnings.push(`The address you provided does not appear to match your selected filing county (${currentCounty}). Your qualifying address must be in the county where you're filing. Please confirm your address or update your filing county.`);
                }
              }
            }

            extractedData[field] = value;
            continue;
          }

          // PHONE VALIDATION
          if (field === 'plaintiffPhone') {
            const digits = value.replace(/\D/g, '');
            if (digits.length === 10) {
              extractedData[field] = value;
              continue;
            }
            if (digits.length === 11 && digits[0] === '1') {
              extractedData[field] = value;
              continue;
            }
            if (digits.length === 9) {
              validationWarnings.push(`That appears to be 9 digits. If this is a US number, it should be 10 digits (area code + 7 digits). Please verify. If it's an international number, include your country code.`);
              extractedData[field] = value;
              continue;
            }
            if (digits.length < 9) {
              validationWarnings.push(`Please provide a complete phone number (10 digits for US, or include country code for international).`);
              continue;
            }
            if (digits.length > 11) {
              extractedData[field] = value;
              continue;
            }
            extractedData[field] = value;
            continue;
          }

          // MARRIAGE DATE VALIDATION — uses canonicalNow
          if (field === 'marriageDate') {
            const mDate = parseDate(value);
            if (!mDate) {
              validationWarnings.push(`Could not parse marriage date. Please use format like "June 15, 2020".`);
              continue;
            }
            if (mDate > canonicalNow) {
              validationWarnings.push(`Marriage date cannot be in the future. Please verify.`);
              continue;
            }
            extractedData[field] = value;
            continue;
          }

          // FILING/SUMMONS DATE VALIDATION — uses canonicalNow
          if (field === 'summonsDate') {
            const sDate = parseDate(value);
            if (!sDate) {
              validationWarnings.push(`Could not parse filing date. Please use format like "January 10, 2026".`);
              continue;
            }
            if (sDate > canonicalNow) {
              validationWarnings.push(`Filing date cannot be in the future. This is the date the clerk accepted your filing. Please verify.`);
              continue;
            }
            if (phase2Data?.marriageDate || extractedData['marriageDate']) {
              const marriageDate = parseDate((phase2Data?.marriageDate || extractedData['marriageDate']) as string);
              if (marriageDate && sDate < marriageDate) {
                validationWarnings.push(`Filing date cannot be before the marriage date. Please verify your dates.`);
                continue;
              }
            }
            extractedData[field] = value;
            continue;
          }

          // BREAKDOWN DATE VALIDATION — uses canonicalNow + state-specific months
          if (field === 'breakdownDate') {
            const bDate = parseDate(value);
            if (!bDate) {
              validationWarnings.push(`Could not parse breakdown date. Please use format like "March 1, 2025".`);
              continue;
            }
            const breakdownMonths = stateConfig.breakdownMonths ?? 6;
            if (!isAtLeastMonthsAgo(bDate, breakdownMonths, canonicalNow)) {
              validationWarnings.push(`The breakdown date must be at least ${breakdownMonths} months before today (${canonicalDateStr}). Please verify.`);
              continue;
            }
            if (phase2Data?.marriageDate || extractedData['marriageDate']) {
              const marriageDate = parseDate((phase2Data?.marriageDate || extractedData['marriageDate']) as string);
              if (marriageDate && bDate < marriageDate) {
                validationWarnings.push(`Breakdown date cannot be before marriage date. Please verify your dates.`);
                continue;
              }
            }
            extractedData[field] = value;
            continue;
          }

          // JUDGMENT ENTRY DATE VALIDATION — uses canonicalNow
          if (field === 'judgmentEntryDate') {
            const entryDate = parseDate(value);
            if (!entryDate) {
              validationWarnings.push(`Could not parse judgment entry date. Please use format like "February 28, 2027".`);
              continue;
            }
            const endOfToday = new Date(canonicalNow);
            endOfToday.setHours(23, 59, 59, 999);
            if (entryDate > endOfToday) {
              validationWarnings.push(`The Judgment entry date cannot be in the future. The Judgment must already be entered before proceeding. Please verify.`);
              continue;
            }
            if (phase2Data?.summonsDate) {
              const summonsDate = parseDate(phase2Data.summonsDate);
              if (summonsDate && entryDate < summonsDate) {
                validationWarnings.push(`Judgment entry date (${value}) cannot be before the filing date (${phase2Data.summonsDate}). Please verify.`);
                continue;
              }
            }
            if (phase2Data?.marriageDate) {
              const marriageDate = parseDate(phase2Data.marriageDate);
              if (marriageDate && entryDate < marriageDate) {
                validationWarnings.push(`Judgment entry date cannot be before the marriage date. Please verify.`);
                continue;
              }
            }
            extractedData[field] = value;
            continue;
          }

          // INDEX NUMBER VALIDATION (NY format)
          if (field === 'indexNumber') {
            const indexMatch = value.match(/^\d+\/\d{4}$/) || value.match(/^\d{4}\/\d+$/);
            if (!indexMatch) {
              validationWarnings.push(`Index number format should be like "12345/2026". Please verify.`);
            }
            extractedData[field] = value;
            continue;
          }

          // DOCKET NUMBER VALIDATION (NJ format)
          if (field === 'docketNumber') {
            const docketMatch = value.match(/^FM-/i);
            if (!docketMatch) {
              validationWarnings.push(`NJ docket number should start with "FM-" (e.g., FM-07-012345-26). Please verify.`);
            }
            extractedData[field] = value;
            continue;
          }

          // Default: save the field
          extractedData[field] = value;
        }
      } catch (e) {
        console.error('JSON parse error:', e);
      }
    }

    // ═══════════════════════════════════════════════════════════════
    // FIX #7: More resilient outside-counsel check
    // Only disqualify if Phase 1 was genuinely never started (no data at all),
    // not just if one field is missing (which could be localStorage corruption)
    // ═══════════════════════════════════════════════════════════════
    if (currentPhase === 2) {
      const hasAnyCaseNumber = extractedData['indexNumber'] || extractedData['docketNumber'];
      const phase1HasAnyData = phase1Data && Object.keys(phase1Data).length > 0;
      if (hasAnyCaseNumber && !phase1HasAnyData) {
        isDisqualified = true;
        disqualifyReason = 'outside_counsel_case';
      }
    }

    // ═══════════════════════════════════════════════════════════════
    // SERVER-SIDE PHASE COMPLETION SAFETY NET
    // Reference: Transparency post Guardrail 05
    // "The server is the authority"
    // ═══════════════════════════════════════════════════════════════

    // Smart field inference: auto-fill address fields
    const mergedP1 = { ...phase1Data, ...extractedData };
    if (mergedP1.plaintiffAddress && !mergedP1.qualifyingAddress && mergedP1.qualifyingParty === 'plaintiff') {
      extractedData['qualifyingAddress'] = mergedP1.plaintiffAddress as string;
    }
    if (mergedP1.qualifyingAddress && !mergedP1.plaintiffAddress && mergedP1.qualifyingParty === 'plaintiff') {
      extractedData['plaintiffAddress'] = mergedP1.qualifyingAddress as string;
    }
    const lastMsg = messages[messages.length - 1]?.content?.toLowerCase() || '';
    if (mergedP1.plaintiffAddress && !mergedP1.defendantAddress &&
        /same address|same one|yes same|same place|lives with me|live together|we both live|living together/.test(lastMsg)) {
      extractedData['defendantAddress'] = mergedP1.plaintiffAddress as string;
    }

    if (currentPhase === 1 && !phase1Complete) {
      const merged = { ...phase1Data, ...extractedData };
      const allPresent = p1Keys.every(f => merged[f]);
      if (allPresent) phase1Complete = true;
    }

    if (currentPhase === 2 && !phase2Complete) {
      const merged = { ...phase2Data, ...extractedData };
      const allPresent = p2Keys.every(f => merged[f]);
      if (allPresent) phase2Complete = true;
    }

    if (currentPhase === 3 && !phase3Complete) {
      const merged = { ...phase3Data, ...extractedData };
      const allPresent = p3Keys.every(f => merged[f]);
      if (allPresent) phase3Complete = true;
    }

    // Clean reply: strip JSON blocks from display, append ALL validation warnings
    let cleanReply = finalReply.replace(/```json\s*[\s\S]*?\s*```/g, '').trim();
    if (validationWarnings.length > 0 && !isTerminated && !isDisqualified) {
      cleanReply = validationWarnings.join('\n\n') + '\n\n' + cleanReply;
    }

    return NextResponse.json({
      reply: cleanReply,
      extractedData: Object.keys(extractedData).length > 0 ? extractedData : null,
      phase1Complete,
      phase2Complete,
      phase3Complete,
      isDisqualified,
      disqualifyReason,
      isTerminated,
      terminateReason,
    });
  } catch (error) {
    console.error('Form filler API error:', error);
    return NextResponse.json(
      { reply: 'Sorry, something went wrong. Please try again.', extractedData: null },
      { status: 500 }
    );
  }
}
