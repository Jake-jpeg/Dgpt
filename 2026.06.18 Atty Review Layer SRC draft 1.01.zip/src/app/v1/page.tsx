'use client';

// ════════════════════════════════════════════════════════════════
// V1.01 PREVIEW — the lawyer-reviewed model, end to end.
//
// Self-contained, in-memory PROTOTYPE so the new flow can be clicked
// through locally at /v1. It touches NO existing V0 routes and NO
// legal-content files.
//
// Boundaries held on purpose:
//   • Disclaimer / positioning copy below is PLACEHOLDER — marked
//     [COUNSEL] — for Jake + counsel to finalize.
//   • The real custody / ED / alimony intake QUESTIONS belong in
//     ny.ts / nj.ts and are authored by the licensed attorney. Here
//     the intake step is a stub.
//   • Persistence is in-memory (resets on refresh) — wire to real
//     storage when productionizing.
//
// What IS real: the triage routing (routeCase), the price tiers, and
// the attorney-review checkpoint workflow.
// ════════════════════════════════════════════════════════════════

import { useState } from 'react';
import { routeCase, type QualifierAnswers } from '@/lib/case-routing';
import { getTier } from '@/lib/pricing-config';
import { FIRM } from '@/lib/firm-config';

type Role = 'client' | 'attorney';
type ClientStep = 'triage' | 'result' | 'intake' | 'submitted';
type SubStatus = 'pending' | 'changes' | 'released';

interface Submission {
  id: string;
  clientName: string;
  tierLabel: string;
  tierPrice: string;
  custodyReviewRequired: boolean;
  reasons: string[];
  status: SubStatus;
  attorneyNote: string;
}

const QUESTIONS: { key: keyof QualifierAnswers; q: string }[] = [
  { key: 'residency', q: 'Have you (or your spouse) met your state residency requirement?' },
  { key: 'uncontested', q: 'Do you and your spouse agree on ending the marriage (uncontested)?' },
  { key: 'children', q: 'Do you have minor children together?' },
  { key: 'property', q: 'Is there property or are there assets to divide?' },
  { key: 'support', q: 'Is alimony / spousal support at issue?' },
  { key: 'military', q: 'Is either spouse active-duty military?' },
  { key: 'domesticViolence', q: 'Is there any history of domestic violence?' },
];

const REASON_LABEL: Record<string, string> = {
  residency_not_met: 'Residency requirement not met',
  domestic_violence: 'Domestic violence present',
  contested: 'Contested — spouses do not agree',
  active_military_scra: 'Active-duty military (SCRA protections)',
  equitable_distribution: 'Property / equitable distribution',
  alimony: 'Alimony / spousal support',
  custody: 'Minor children / custody',
  simple_uncontested: 'Simple uncontested',
};

const NAVY = '#1a365d';
const GOLD = '#c59d5f';

export default function V1Preview() {
  const [role, setRole] = useState<Role>('client');
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  const [step, setStep] = useState<ClientStep>('triage');
  const [answers, setAnswers] = useState<Partial<QualifierAnswers>>({});
  const [clientName, setClientName] = useState('');
  const [activeSubId, setActiveSubId] = useState<string | null>(null);

  const allAnswered = QUESTIONS.every((q) => answers[q.key] !== undefined);
  const routing = allAnswered ? routeCase(answers as QualifierAnswers) : null;
  const tier = routing && routing.outcome === 'reviewed' ? getTier(routing.tier) : null;
  const activeSub = submissions.find((s) => s.id === activeSubId) || null;
  const pendingCount = submissions.filter((s) => s.status === 'pending').length;

  function setAnswer(key: keyof QualifierAnswers, val: boolean) {
    setAnswers((a) => ({ ...a, [key]: val }));
  }

  function submitForReview() {
    if (!routing || routing.outcome !== 'reviewed' || !tier) return;
    const id = 'sub_' + Date.now();
    setSubmissions((s) => [
      ...s,
      {
        id,
        clientName: clientName || 'Unnamed client',
        tierLabel: tier.label,
        tierPrice: tier.priceDisplay,
        custodyReviewRequired: routing.custodyReviewRequired,
        reasons: routing.reasons,
        status: 'pending',
        attorneyNote: '',
      },
    ]);
    setActiveSubId(id);
    setStep('submitted');
  }

  function updateStatus(id: string, status: SubStatus, note: string) {
    setSubmissions((s) => s.map((x) => (x.id === id ? { ...x, status, attorneyNote: note } : x)));
  }

  function resetClient() {
    setStep('triage');
    setAnswers({});
    setClientName('');
    setActiveSubId(null);
  }

  const statusPill = (status: SubStatus) => {
    const map: Record<SubStatus, { t: string; c: string }> = {
      pending: { t: 'Pending attorney review', c: 'bg-amber-100 text-amber-800' },
      changes: { t: 'Changes requested', c: 'bg-rose-100 text-rose-800' },
      released: { t: 'Approved & released', c: 'bg-emerald-100 text-emerald-800' },
    };
    const m = map[status];
    return <span className={`rounded-full px-3 py-1 text-xs font-semibold ${m.c}`}>{m.t}</span>;
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900">
      {/* Header */}
      <header className="border-b border-zinc-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold" style={{ color: NAVY }}>DivorceGPT</span>
              <span className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white" style={{ background: GOLD }}>
                V1 PREVIEW
              </span>
            </div>
            <p className="text-xs text-zinc-500">
              Reviewed by {FIRM.attorneyName} · {FIRM.name}
            </p>
          </div>
          <div className="flex overflow-hidden rounded-full border border-zinc-300 text-sm">
            <button
              onClick={() => setRole('client')}
              className={`px-4 py-1.5 font-medium ${role === 'client' ? 'text-white' : 'text-zinc-600'}`}
              style={role === 'client' ? { background: NAVY } : {}}
            >
              Client
            </button>
            <button
              onClick={() => setRole('attorney')}
              className={`px-4 py-1.5 font-medium ${role === 'attorney' ? 'text-white' : 'text-zinc-600'}`}
              style={role === 'attorney' ? { background: NAVY } : {}}
            >
              Attorney{pendingCount > 0 ? ` (${pendingCount})` : ''}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-6 py-10">
        {role === 'client' ? (
          <ClientFlow />
        ) : (
          <AttorneyFlow />
        )}
      </main>

      <footer className="mx-auto max-w-3xl px-6 pb-10 text-center text-xs text-zinc-400">
        [COUNSEL] Placeholder: under the reviewed model, a licensed attorney reviews every file
        before release. Final positioning &amp; engagement language to be set by Jake + counsel.
        This preview uses mock data and resets on refresh.
      </footer>
    </div>
  );

  // ── Client-facing flow ──────────────────────────────────────────
  function ClientFlow() {
    if (step === 'triage') {
      return (
        <section>
          <h1 className="text-2xl font-bold" style={{ color: NAVY }}>Tell us about your case</h1>
          <p className="mt-1 text-sm text-zinc-500">
            Same screener as today — but now it routes you to the right reviewed service instead of a flat DIY checkout.
          </p>
          <div className="mt-6 space-y-3">
            {QUESTIONS.map((q) => (
              <div key={q.key} className="flex items-center justify-between rounded-xl border border-zinc-200 bg-white p-4">
                <span className="pr-4 text-sm">{q.q}</span>
                <div className="flex shrink-0 gap-2">
                  {([['Yes', true], ['No', false]] as const).map(([label, val]) => (
                    <button
                      key={label}
                      onClick={() => setAnswer(q.key, val)}
                      className={`rounded-lg px-4 py-1.5 text-sm font-medium ${
                        answers[q.key] === val ? 'text-white' : 'border border-zinc-300 text-zinc-600'
                      }`}
                      style={answers[q.key] === val ? { background: NAVY } : {}}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <button
            disabled={!allAnswered}
            onClick={() => setStep('result')}
            className="mt-6 w-full rounded-full py-3 font-semibold text-white disabled:opacity-40"
            style={{ background: GOLD }}
          >
            See my options
          </button>
        </section>
      );
    }

    if (step === 'result' && routing) {
      if (routing.outcome === 'ineligible') {
        return (
          <ResultCard title="This may be outside our scope" tone="warn">
            <p className="text-sm">{routing.reasons.map((r) => REASON_LABEL[r] || r).join(', ')}.</p>
            <p className="mt-2 text-sm text-zinc-500">[COUNSEL] Placeholder guidance for non-qualifying cases.</p>
            <BackBtn />
          </ResultCard>
        );
      }
      if (routing.outcome === 'direct_to_human') {
        return (
          <ResultCard title="This case goes straight to an attorney" tone="warn">
            <p className="text-sm">
              Based on your answers, this is handled directly by a lawyer — not drafted by AI:
            </p>
            <ul className="mt-2 list-disc pl-5 text-sm">
              {routing.reasons.map((r) => <li key={r}>{REASON_LABEL[r] || r}</li>)}
            </ul>
            <p className="mt-3 text-sm font-medium" style={{ color: NAVY }}>
              Next step: book a consult with {FIRM.attorneyName}.
            </p>
            <BackBtn />
          </ResultCard>
        );
      }
      // reviewed
      return (
        <ResultCard title="Attorney-reviewed divorce" tone="ok">
          {tier && (
            <>
              <div className="flex items-baseline justify-between">
                <span className="font-semibold">{tier.label}</span>
                <span className="text-2xl font-bold" style={{ color: NAVY }}>{tier.priceDisplay}</span>
              </div>
              <p className="mt-2 text-sm text-zinc-600">{tier.blurb}</p>
            </>
          )}
          {routing.custodyReviewRequired && (
            <div className="mt-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
              <strong>Custody flagged.</strong> The parenting arrangement will be reviewed and signed off
              by the attorney before anything is filed.
            </div>
          )}
          <button
            onClick={() => setStep('intake')}
            className="mt-5 w-full rounded-full py-3 font-semibold text-white"
            style={{ background: NAVY }}
          >
            Continue
          </button>
          <BackBtn />
        </ResultCard>
      );
    }

    if (step === 'intake') {
      return (
        <section>
          <h1 className="text-2xl font-bold" style={{ color: NAVY }}>Your information</h1>
          <div className="mt-2 rounded-lg border border-dashed border-zinc-300 bg-white p-3 text-xs text-zinc-500">
            [ATTORNEY] The full custody / ED / alimony intake questions are authored in the legal config
            (ny.ts / nj.ts) by the licensed attorney. This preview captures just a name to demonstrate the handoff.
          </div>
          <input
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder="Your full legal name"
            className="mt-4 w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm"
          />
          <button
            onClick={submitForReview}
            className="mt-5 w-full rounded-full py-3 font-semibold text-white"
            style={{ background: GOLD }}
          >
            Submit for attorney review
          </button>
        </section>
      );
    }

    if (step === 'submitted') {
      return (
        <section className="text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full text-white" style={{ background: NAVY }}>
            ✓
          </div>
          <h1 className="text-2xl font-bold" style={{ color: NAVY }}>Submitted</h1>
          <p className="mt-2 text-sm text-zinc-600">
            Your packet is being prepared by AI and will be reviewed by {FIRM.attorneyName} before it is released to you.
          </p>
          <div className="mt-5 inline-block">{activeSub && statusPill(activeSub.status)}</div>
          {activeSub?.status === 'released' && (
            <p className="mt-4 text-sm font-medium text-emerald-700">
              Your reviewed packet is ready to download. (mock)
            </p>
          )}
          {activeSub?.status === 'changes' && activeSub.attorneyNote && (
            <p className="mt-4 text-sm text-rose-700">Attorney note: {activeSub.attorneyNote}</p>
          )}
          <p className="mt-6 text-xs text-zinc-400">
            Switch to the <strong>Attorney</strong> tab above to review this file and watch this status change live.
          </p>
          <button onClick={resetClient} className="mt-4 text-sm font-medium underline" style={{ color: NAVY }}>
            Start another (demo)
          </button>
        </section>
      );
    }

    return null;
  }

  function ResultCard(props: { title: string; tone: 'ok' | 'warn'; children: React.ReactNode }) {
    return (
      <section className="rounded-2xl border border-zinc-200 bg-white p-6">
        <h1 className="text-xl font-bold" style={{ color: props.tone === 'ok' ? NAVY : '#9a3412' }}>{props.title}</h1>
        <div className="mt-3">{props.children}</div>
      </section>
    );
  }

  function BackBtn() {
    return (
      <button onClick={resetClient} className="mt-4 block text-sm font-medium underline" style={{ color: NAVY }}>
        Start over
      </button>
    );
  }

  // ── Attorney-facing review checkpoint ───────────────────────────
  function AttorneyFlow() {
    return (
      <section>
        <h1 className="text-2xl font-bold" style={{ color: NAVY }}>Review queue</h1>
        <p className="mt-1 text-sm text-zinc-500">
          Every AI-drafted file lands here for sign-off before it reaches the client. {pendingCount} pending.
        </p>
        {submissions.length === 0 && (
          <p className="mt-8 rounded-xl border border-dashed border-zinc-300 bg-white p-6 text-center text-sm text-zinc-500">
            No submissions yet. Switch to the <strong>Client</strong> tab, run a case through, and submit it.
          </p>
        )}
        <div className="mt-6 space-y-4">
          {submissions.map((s) => (
            <div key={s.id} className="rounded-2xl border border-zinc-200 bg-white p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold">{s.clientName}</p>
                  <p className="text-sm text-zinc-500">{s.tierLabel} · {s.tierPrice}</p>
                </div>
                {statusPill(s.status)}
              </div>

              {s.custodyReviewRequired && (
                <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
                  <strong>Mandatory custody review.</strong> Confirm the parenting arrangement is sane before release.
                </div>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                {s.reasons.map((r) => (
                  <span key={r} className="rounded-full bg-zinc-100 px-3 py-1 text-xs text-zinc-600">
                    {REASON_LABEL[r] || r}
                  </span>
                ))}
              </div>

              {s.status === 'pending' && (
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => updateStatus(s.id, 'released', '')}
                    className="rounded-full px-4 py-2 text-sm font-semibold text-white"
                    style={{ background: NAVY }}
                  >
                    Approve &amp; release
                  </button>
                  <button
                    onClick={() => updateStatus(s.id, 'changes', 'Please confirm the parenting schedule and re-submit.')}
                    className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold text-zinc-700"
                  >
                    Request changes
                  </button>
                </div>
              )}
              {s.status !== 'pending' && (
                <button
                  onClick={() => updateStatus(s.id, 'pending', '')}
                  className="mt-4 text-xs font-medium underline text-zinc-500"
                >
                  Reopen (demo)
                </button>
              )}
            </div>
          ))}
        </div>
      </section>
    );
  }
}
