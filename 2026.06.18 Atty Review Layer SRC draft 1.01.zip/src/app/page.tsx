"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { PRICING_TIERS } from "@/lib/pricing-config";
import { FIRM } from "@/lib/firm-config";

const states = [
  { code: "ny", name: "New York", abbr: "NY", live: true, href: "/ny", tagline: "Uncontested divorce — AI-prepared, attorney-reviewed.", counties: "All 62 counties" },
  { code: "nj", name: "New Jersey", abbr: "NJ", live: true, href: "/nj", tagline: "Uncontested divorce for New Jersey residents — attorney-reviewed.", counties: "All 21 counties" },
];

const YOUTUBE_VIDEO_ID = "nA9bf64rrA8";

// Reviewed-service tiers are the source of truth (src/lib/pricing-config.ts).
const premiumTier = PRICING_TIERS.find((t) => t.id === "ed_alimony")!; // featured, middle
const custodyTier = PRICING_TIERS.find((t) => t.id === "custody")!;
const simpleTier = PRICING_TIERS.find((t) => t.id === "simple")!;      // entry, right
const consultTier = PRICING_TIERS.find((t) => t.id === "consult");
const fromTier = simpleTier;

export default function Home() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  if (!mounted) return <div className="min-h-screen bg-zinc-50 flex items-center justify-center"><div className="h-12 w-12 animate-spin rounded-full border-4 border-[#1a365d] border-t-transparent" /></div>;

  return (
    <div className="min-h-screen bg-zinc-50">
      <header className="sticky top-0 z-50 backdrop-blur-sm bg-white/80 border-b border-zinc-100">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#1a365d] to-[#2c5282] shadow-lg shadow-[#1a365d]/20"><span className="text-lg">⚖️</span></div>
              <div><h1 className="text-lg font-semibold text-zinc-900">DivorceGPT</h1><p className="text-xs text-zinc-500">Reviewed by {FIRM.name}</p></div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#0f2440] via-[#1a365d] to-[#1e3a5f] pt-20 pb-16 lg:pt-20 lg:pb-20">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-[#c59d5f]/8 blur-[100px]" />
          <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-[#c59d5f]/5 blur-[100px]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

            <div className="order-1">
              <span className="inline-flex items-center gap-2 rounded-full bg-[#c59d5f]/15 px-3 py-1 text-xs font-semibold text-[#e8c98a] ring-1 ring-[#c59d5f]/30">
                Now attorney-reviewed
              </span>
              <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-[56px] lg:leading-[1.1]">
                Uncontested Divorce, Reviewed by a Real Attorney
              </h1>
              <p className="mt-5 text-lg text-zinc-300 leading-relaxed max-w-xl">
                AI prepares your New York or New Jersey divorce forms in plain language — then a licensed
                matrimonial attorney reviews every file before it is filed. Flat fee, limited scope, no hourly billing.
              </p>

              <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2">
                {["Every file reviewed by a licensed NY/NJ attorney", "Flat-fee limited-scope representation", "Court-ready documents"].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                    <svg className="h-4 w-4 text-[#c59d5f] flex-shrink-0" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
                    {item}
                  </li>
                ))}
              </ul>

              <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <div className="relative">
                  <select
                    defaultValue=""
                    onChange={(e) => { if (e.target.value) window.location.href = e.target.value; }}
                    className="appearance-none w-full sm:w-52 rounded-full bg-white/10 backdrop-blur-sm text-white pl-5 pr-10 py-3.5 text-sm font-medium ring-1 ring-white/20 focus:ring-[#c59d5f] focus:outline-none cursor-pointer"
                  >
                    <option value="" disabled className="text-zinc-900">Select Your State</option>
                    <option value="/ny" className="text-zinc-900">New York</option>
                    <option value="/nj" className="text-zinc-900">New Jersey</option>
                  </select>
                  <svg className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400 pointer-events-none" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" /></svg>
                </div>
                <Link href="#states" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#c59d5f] px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-[#c59d5f]/25 hover:bg-[#d4ac6e] hover:shadow-xl transition-all">
                  Start Your Divorce →
                </Link>
              </div>
              <div className="mt-3">
                <Link href="#pricing" className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-400 hover:text-white transition">
                  See Pricing ↓
                </Link>
              </div>
            </div>

            <div className="order-2">
              <div className="relative rounded-2xl bg-[#1f3a5c] p-2 shadow-2xl shadow-black/30">
                <div
                  className="relative rounded-xl overflow-hidden aspect-video bg-black cursor-pointer group"
                  onClick={(e) => {
                    const container = e.currentTarget;
                    container.innerHTML = '<iframe src="https://www.youtube.com/embed/' + YOUTUBE_VIDEO_ID + '?rel=0&modestbranding=1&autoplay=1" title="DivorceGPT Demo" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="absolute inset-0 w-full h-full" style="border:0" />';
                  }}
                >
                  <img
                    src={`https://img.youtube.com/vi/${YOUTUBE_VIDEO_ID}/maxresdefault.jpg`}
                    alt="DivorceGPT demo — AI-prepared, attorney-reviewed divorce documents"
                    className="absolute inset-0 w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#c59d5f] shadow-xl shadow-[#c59d5f]/40 group-hover:scale-110 transition-transform">
                      <svg className="h-7 w-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Pricing — Free + attorney-reviewed anchor tiers (from pricing-config) */}
      <section id="pricing" className="py-24 bg-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">Flat-Fee, Attorney-Reviewed</h3>
            <p className="mt-4 text-lg text-zinc-600">AI does the drafting. A licensed attorney reviews every file before you file. You confirm eligibility first — pricing matches your case.</p>
          </div>
          <div className="grid gap-8 md:grid-cols-3 max-w-6xl mx-auto items-stretch">

            {/* LEFT: Free DIY */}
            <div className="rounded-2xl bg-white p-8 ring-1 ring-zinc-200 hover:shadow-lg transition-all duration-300 flex flex-col min-h-[560px]">
              <h4 className="text-lg font-bold text-zinc-900">DIY — Do It Yourself</h4>
              <div className="mt-3"><span className="text-4xl font-bold text-[#1a365d]">Free</span></div>
              <p className="mt-3 text-sm text-zinc-500">Download the official court forms yourself. Self-guided, no attorney review.</p>
              <ul className="mt-6 space-y-3 flex-1">
                {["Official court forms — no charge", "Available from your state court website", "Self-guided — you fill out everything", "File at your county courthouse or e-file", "No attorney review"].map((f, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm text-zinc-600"><svg className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#c59d5f]" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>{f}</li>
                ))}
              </ul>
              <div className="mt-8"><Link href="/free-forms" className="block w-full rounded-full py-3 text-center text-sm font-semibold bg-zinc-100 text-zinc-700 hover:bg-zinc-200 transition">Get Free Court Forms →</Link></div>
            </div>

            {/* MIDDLE: PREMIUM (featured, blue) — $1,500 */}
            <div className="relative rounded-2xl bg-gradient-to-b from-[#1a365d] to-[#234876] p-8 text-white shadow-xl shadow-[#1a365d]/20 ring-2 ring-[#c59d5f] md:-translate-y-4 flex flex-col min-h-[560px]">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2"><span className="inline-flex items-center rounded-full bg-[#c59d5f] px-4 py-1 text-xs font-bold text-white shadow-lg shadow-[#c59d5f]/30">Most chosen</span></div>
              <h4 className="text-lg font-bold text-white">{premiumTier.label}</h4>
              <div className="mt-3"><span className="text-4xl font-bold text-[#c59d5f]">{premiumTier.priceDisplay}</span></div>
              <p className="mt-3 text-sm text-zinc-300">{premiumTier.blurb}</p>
              <ul className="mt-6 space-y-3 flex-1">
                {["Equitable distribution and/or alimony handled", "Reviewed by a licensed NY/NJ attorney", "State & county-specific documents", "Financial terms reviewed before filing", "Court-ready packet to file"].map((f, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm text-zinc-200"><svg className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#c59d5f]" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>{f}</li>
                ))}
              </ul>
              <div className="mt-8"><Link href="#states" className="block w-full rounded-full py-3 text-center text-sm font-semibold bg-[#c59d5f] text-white shadow-lg shadow-[#c59d5f]/30 hover:bg-[#d4ac6e] transition">Check eligibility →</Link></div>
            </div>

            {/* RIGHT: Simple reviewed — $500 */}
            <div className="rounded-2xl bg-white p-8 ring-1 ring-zinc-200 hover:shadow-lg transition-all duration-300 flex flex-col min-h-[560px]">
              <h4 className="text-lg font-bold text-zinc-900">{simpleTier.label}</h4>
              <div className="mt-3"><span className="text-4xl font-bold text-[#1a365d]">{simpleTier.priceDisplay}</span></div>
              <p className="mt-3 text-sm text-zinc-500">{simpleTier.blurb}</p>
              <ul className="mt-6 space-y-3 flex-1">
                {["AI-prepared in plain language", "Reviewed by a licensed NY/NJ attorney", "State & county-specific documents", "Court-ready packet to file"].map((f, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm text-zinc-600"><svg className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#c59d5f]" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>{f}</li>
                ))}
              </ul>
              <div className="mt-8"><Link href="#states" className="block w-full rounded-full py-3 text-center text-sm font-semibold bg-zinc-100 text-zinc-700 hover:bg-zinc-200 transition">Check eligibility →</Link></div>
            </div>

          </div>

          <p className="mt-8 text-center text-sm text-zinc-600">
            Cases with children or custody fall under a <strong>{custodyTier.priceDisplay}</strong> tier — you are matched to the right tier when you check eligibility.
          </p>

          {consultTier && (
            <div className="mt-6 rounded-2xl border border-zinc-200 bg-zinc-50 p-6 text-center">
              <p className="text-sm text-zinc-700">{consultTier.blurb}</p>
            </div>
          )}

          <p className="mt-8 text-center text-sm text-zinc-500">
            Prefer to do it yourself? <Link href="/free-forms" className="font-medium text-[#1a365d] underline">Free court forms</Link> and <Link href="/guides" className="font-medium text-[#1a365d] underline">plain-language guides</Link> remain available at no cost.
          </p>
        </div>
      </section>

      {/* Select State */}
      <section id="states" className="py-24 bg-zinc-50">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">Attorney-Reviewed Divorce — Select Your State</h3>
            <p className="mt-4 text-lg text-zinc-600">Flat fee from {fromTier.priceDisplay} · every file attorney-reviewed. Eligibility check required.</p>
          </div>
          <div className="grid gap-8 md:grid-cols-2">
            {states.map((s) => (
              <Link key={s.code} href={s.live ? `/${s.code}` : s.href} className={`group relative rounded-2xl p-8 transition-all duration-300 ${s.live ? "bg-gradient-to-b from-[#1a365d] to-[#234876] text-white shadow-xl shadow-[#1a365d]/20 hover:shadow-2xl hover:-translate-y-1" : "bg-white text-zinc-900 ring-1 ring-zinc-200 hover:ring-zinc-300 hover:shadow-lg"}`}>
                <div className={`inline-flex h-14 w-14 items-center justify-center rounded-xl text-xl font-bold ${s.live ? "bg-[#c59d5f] text-white shadow-lg shadow-[#c59d5f]/30" : "bg-zinc-200 text-zinc-400"}`}>{s.abbr}</div>
                <div className="mt-6">
                  <h4 className={`text-2xl font-bold ${s.live ? "text-white" : "text-zinc-900"}`}>{s.name}</h4>
                  {s.live ? (<span className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-green-500/20 px-3 py-1 text-xs font-semibold text-green-300"><span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />Live Now</span>) : (<span className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-yellow-500/20 px-3 py-1 text-xs font-semibold text-yellow-600"><span className="h-1.5 w-1.5 rounded-full bg-yellow-500 animate-pulse" />Under Construction</span>)}
                </div>
                <p className={`mt-4 text-sm ${s.live ? "text-zinc-300" : "text-zinc-500"}`}>{s.tagline}</p>
                <div className={`mt-6 flex items-center justify-between border-t pt-4 ${s.live ? "border-white/10" : "border-zinc-200"}`}>
                  <span className="text-sm text-zinc-400">{s.counties}</span>
                  {s.live && <span className="text-sm font-semibold text-[#c59d5f]">From {fromTier.priceDisplay}</span>}
                </div>
                {s.live && <div className="absolute top-8 right-8 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 transition-all group-hover:bg-[#c59d5f] group-hover:shadow-lg"><svg className="h-5 w-5 text-white transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" /></svg></div>}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works — reviewed flow */}
      <section className="py-24 bg-white">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16"><h3 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">How It Works</h3></div>
          <div className="grid gap-6 md:grid-cols-4 max-w-5xl mx-auto">
            {[
              { icon: "✅", title: "Qualify", body: "Answer a short screener. We confirm your case fits and route you to the right flat-fee tier." },
              { icon: "🤖", title: "AI prepares", body: "AI drafts your state- and county-specific packet in plain language, explaining every field." },
              { icon: "⚖️", title: "Attorney reviews", body: "A licensed NY/NJ matrimonial attorney reviews every file before anything is released." },
              { icon: "📄", title: "You file", body: "You receive your reviewed, court-ready packet with filing instructions." },
            ].map((p, i) => (
              <div key={i} className="rounded-2xl bg-zinc-50 p-6 ring-1 ring-zinc-100">
                <span className="text-3xl">{p.icon}</span>
                <div className="mt-3 flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#1a365d] text-xs font-bold text-white">{i + 1}</span><h4 className="text-base font-bold text-zinc-900">{p.title}</h4></div>
                <p className="mt-3 text-sm text-zinc-600">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-100 bg-zinc-900 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <div className="flex items-center gap-3 mb-4"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-[#1a365d] to-[#2c5282]"><span className="text-sm">⚖️</span></div><span className="font-semibold text-white">DivorceGPT</span></div>
              <p className="text-sm text-zinc-400">AI-prepared, attorney-reviewed divorce documents.</p>
              <p className="mt-1 text-xs text-zinc-500">Legal review by {FIRM.name}</p>
              <p className="mt-2 text-xs text-zinc-500">© 2025 June Guided Solutions, LLC</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Services</h4>
              <div className="space-y-2 text-sm">
                <Link href="#states" className="block text-zinc-400 hover:text-[#c59d5f] transition">Attorney-Reviewed Divorce (from {fromTier.priceDisplay})</Link>
                <Link href="/free-forms" className="block text-zinc-400 hover:text-[#c59d5f] transition">Free Court Forms</Link>
                <Link href="/guides" className="block text-zinc-400 hover:text-[#c59d5f] transition">Resource Guides</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Company</h4>
              <div className="space-y-2 text-sm">
                <a href="https://juneguidedsolutions.com" className="block text-zinc-400 hover:text-[#c59d5f] transition">June Guided Solutions, LLC</a>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Legal</h4>
              <div className="space-y-2 text-sm">
                <Link href="/privacy" className="block text-zinc-400 hover:text-[#c59d5f] transition">Privacy Policy</Link>
                <Link href="/terms" className="block text-zinc-400 hover:text-[#c59d5f] transition">Terms of Service</Link>
              </div>
              {/* [COUNSEL] Finalize exact engagement / attorney-client language before launch. */}
              <p className="mt-4 text-xs text-zinc-500">DivorceGPT is software by June Guided Solutions, LLC. Legal review and limited-scope representation are provided by {FIRM.name}. An attorney-client relationship is formed only upon execution of a limited-scope engagement agreement.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
