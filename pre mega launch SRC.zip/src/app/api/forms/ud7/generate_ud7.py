#!/usr/bin/env python3
"""
DivorceGPT UD-7 (Affidavit of Defendant) PDF Generator
=======================================================

Defendant's affidavit consenting to uncontested divorce.
Simplified for DivorceGPT scope: no children, no assets, no maintenance.
"""

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Page dimensions
PAGE_WIDTH, PAGE_HEIGHT = letter  # 612 x 792 points
MARGIN_LEFT = 72   # 1 inch
MARGIN_RIGHT = 72
MARGIN_TOP = 72
MARGIN_BOTTOM = 72

# Content area
CONTENT_WIDTH = PAGE_WIDTH - MARGIN_LEFT - MARGIN_RIGHT  # 468 points

# Line height
LINE_HEIGHT = 14

# Box layout positions
BOX1_LEFT_X = MARGIN_LEFT
BOX1_RIGHT_X = PAGE_WIDTH / 2

BOX2_LEFT_X = PAGE_WIDTH / 2
BOX2_RIGHT_X = PAGE_WIDTH - MARGIN_RIGHT


def draw_wrapped_text(c, text, x, y, max_width, font_name="Times-Roman", font_size=12):
    """Draw text that wraps within max_width. Returns final Y position."""
    c.setFont(font_name, font_size)
    words = text.split()
    lines = []
    current_line = []
    current_width = 0
    space_width = c.stringWidth(' ', font_name, font_size)
    
    for word in words:
        word_width = c.stringWidth(word, font_name, font_size)
        test_width = current_width + word_width + (space_width if current_line else 0)
        
        if test_width <= max_width:
            current_line.append(word)
            current_width = test_width
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
            current_width = word_width
    
    if current_line:
        lines.append(' '.join(current_line))
    
    for line in lines:
        c.drawString(x, y, line)
        y -= LINE_HEIGHT
    
    return y


def generate_ud7(data, output_path):
    """Generate UD-7 (Affidavit of Defendant) PDF."""
    
    c = canvas.Canvas(output_path, pagesize=letter)
    
    # Extract variables
    county_name = data.get('county', '').strip()
    county_upper = county_name.upper()
    
    plaintiff_name = data.get('plaintiffName', '').strip()
    defendant_name = data.get('defendantName', '').strip()
    index_number = data.get('indexNumber', '').strip()
    
    defendant_address = data.get('defendantAddress', '').strip()
    
    # Service date and grounds
    service_date = data.get('serviceDate', '').strip()
    
    # Religious ceremony - affects barriers to remarriage section
    religious_ceremony = data.get('religiousCeremony', False)
    
    # For affirmation
    state_signed = data.get('stateSigned', 'NEW YORK').strip().upper()
    county_signed = data.get('countySigned', county_name).strip().upper()
    
    # =========================================================================
    # PAGE 1
    # =========================================================================
    
    y = PAGE_HEIGHT - MARGIN_TOP
    
    # Header
    c.setFont("Times-Bold", 12)
    c.drawString(MARGIN_LEFT, y, "SUPREME COURT OF THE STATE OF NEW YORK")
    y -= LINE_HEIGHT
    c.drawString(MARGIN_LEFT, y, f"COUNTY OF {county_upper}")
    y -= LINE_HEIGHT * 1.5
    
    # Caption box
    boxes_top_y = y
    box_height = LINE_HEIGHT * 8
    boxes_bottom_y = boxes_top_y - box_height
    
    # Draw box borders
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.5)
    
    c.line(BOX1_LEFT_X, boxes_top_y, BOX1_RIGHT_X, boxes_top_y)
    c.line(BOX1_RIGHT_X, boxes_top_y, BOX1_RIGHT_X, boxes_bottom_y)
    c.line(BOX1_LEFT_X, boxes_bottom_y, BOX1_RIGHT_X, boxes_bottom_y)
    c.line(BOX2_LEFT_X, boxes_top_y, BOX2_LEFT_X, boxes_bottom_y)
    
    # Left box - Caption
    box1_x = BOX1_LEFT_X + 8
    caption_y = boxes_top_y - LINE_HEIGHT * 1.5
    
    c.setFont("Times-Roman", 12)
    c.drawString(box1_x, caption_y, f"{plaintiff_name},")
    caption_y -= LINE_HEIGHT
    c.setFont("Times-Italic", 12)
    c.drawString(box1_x + 40, caption_y, "Plaintiff,")
    caption_y -= LINE_HEIGHT * 1.5
    c.setFont("Times-Roman", 12)
    c.drawString(box1_x + 40, caption_y, "-against-")
    caption_y -= LINE_HEIGHT * 1.5
    c.drawString(box1_x, caption_y, f"{defendant_name}.")
    caption_y -= LINE_HEIGHT
    c.setFont("Times-Italic", 12)
    c.drawString(box1_x + 40, caption_y, "Defendant.")
    
    # Right box - Title
    box2_x = BOX2_LEFT_X + 8
    title_y = boxes_top_y - LINE_HEIGHT * 1.5
    
    c.setFont("Times-Roman", 12)
    if index_number:
        c.drawString(box2_x, title_y, f"Index No.: {index_number}")
    else:
        c.drawString(box2_x, title_y, "Index No.: _______________")
    title_y -= LINE_HEIGHT * 2.5
    
    c.setFont("Times-Bold", 12)
    box2_center = BOX2_LEFT_X + (BOX2_RIGHT_X - BOX2_LEFT_X) / 2
    title_text = "AFFIDAVIT OF DEFENDANT"
    title_width = c.stringWidth(title_text, "Times-Bold", 12)
    c.drawString(box2_center - title_width/2, title_y, title_text)
    
    # Body content
    y = boxes_bottom_y - LINE_HEIGHT * 1.5
    
    # State/County line
    c.setFont("Times-Roman", 12)
    c.drawString(MARGIN_LEFT, y, f"STATE OF {state_signed}, COUNTY OF {county_signed}, ss:")
    y -= LINE_HEIGHT * 1.5
    
    # Opening - Defendant's name and address
    defendant_address_display = defendant_address if defendant_address else "_____________________________________________"
    
    para_open = f"{defendant_name}, being duly sworn, says:"
    y = draw_wrapped_text(c, para_open, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT
    
    para1 = f"I am the Defendant in the within action for divorce, and I am over the age of 18. I reside at {defendant_address_display}."
    y = draw_wrapped_text(c, para1, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # 1. Service acknowledgment
    service_date_display = service_date if service_date else "_______________"
    para2 = f"1. I admit service of the Summons with Notice dated {service_date_display}, wherein the grounds for divorce alleged are: DRL §170 subd. (7) - The relationship between Plaintiff and Defendant has broken down irretrievably for a period of at least six months."
    y = draw_wrapped_text(c, para2, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT
    
    para2b = "I also admit service of the Notice of Automatic Orders and the Notice of Guideline Maintenance."
    y = draw_wrapped_text(c, para2b, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # 2. Consent to uncontested calendar
    para3 = "2. I appear in this action; however, I do not intend to respond to the summons or answer the complaint, and I waive the twenty (20) or thirty (30) day period provided by law to respond to the summons or answer the complaint. I waive the forty (40) day waiting period to place this matter on the calendar, and I hereby consent to this action being placed on the uncontested divorce calendar immediately."
    y = draw_wrapped_text(c, para3, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # Check page break
    if y < MARGIN_BOTTOM + LINE_HEIGHT * 8:
        c.showPage()
        y = PAGE_HEIGHT - MARGIN_TOP
        c.setFont("Times-Roman", 12)
    
    # 3. Military status
    c.drawString(MARGIN_LEFT, y, "3. [X] I am not a member of the military service of this state, any other state, or this nation.")
    y -= LINE_HEIGHT * 1.5
    
    # 4. Waiver of further papers
    para4 = "4. [X] I waive service of all further papers in this action except for a copy of the final Judgment of Divorce."
    y = draw_wrapped_text(c, para4, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # 5. No equitable distribution / maintenance
    para5a = "5a. I am not seeking equitable distribution other than what was already agreed to in a written stipulation. I understand that I may be prevented from further asserting my right to equitable distribution."
    y = draw_wrapped_text(c, para5a, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT
    
    para5b = "5b. [X] I am not seeking maintenance as payee."
    y = draw_wrapped_text(c, para5b, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # Check page break
    if y < MARGIN_BOTTOM + LINE_HEIGHT * 8:
        c.showPage()
        y = PAGE_HEIGHT - MARGIN_TOP
        c.setFont("Times-Roman", 12)
    
    # 6. Barriers to remarriage
    if religious_ceremony:
        para6a = "6a. I will take or have taken all steps solely within my power to remove any barriers to the Plaintiff's remarriage."
        y = draw_wrapped_text(c, para6a, MARGIN_LEFT, y, CONTENT_WIDTH)
        y -= LINE_HEIGHT
        para6b = "6b. [ ] I waive the requirements of DRL §253 subdivisions (2), (3), and (4)."
        y = draw_wrapped_text(c, para6b, MARGIN_LEFT, y, CONTENT_WIDTH)
    else:
        para6 = "6. The Barriers to Remarriage provisions (DRL §253) do not apply as the marriage was not performed in a religious ceremony."
        y = draw_wrapped_text(c, para6, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # 7. No children
    para7 = "7. There are no children of the marriage under the age of 21."
    y = draw_wrapped_text(c, para7, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # 8. Health care notice
    para8 = "8. I have been provided a copy of Notice Relating to Health Care of the Parties. I fully understand that upon the entrance of this divorce judgment, I may no longer be allowed to receive health coverage under my former spouse's health insurance plan."
    y = draw_wrapped_text(c, para8, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 1.5
    
    # Check page break before signature
    if y < MARGIN_BOTTOM + LINE_HEIGHT * 10:
        c.showPage()
        y = PAGE_HEIGHT - MARGIN_TOP
        c.setFont("Times-Roman", 12)
    
    # 9. Guideline maintenance notice
    para9 = "9. I acknowledge receipt of the Notice of Guideline Maintenance."
    y = draw_wrapped_text(c, para9, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 2
    
    # Affirmation under penalty of perjury
    affirm_text = "I, ________________________ (print or type name), affirm this ___ day of ______, ____, under the penalties of perjury, under the laws of New York, which may include a fine or imprisonment, that the foregoing is true, except as to matters alleged on information and belief and as to those matters I believe it to be true, and I understand that this document may be filed in an action or proceeding in a court of law."
    y = draw_wrapped_text(c, affirm_text, MARGIN_LEFT, y, CONTENT_WIDTH)
    y -= LINE_HEIGHT * 3
    
    # Signature line
    c.line(MARGIN_LEFT, y, MARGIN_LEFT + 250, y)
    y -= LINE_HEIGHT
    c.setFont("Times-Roman", 12)
    c.drawString(MARGIN_LEFT, y, defendant_name)
    y -= LINE_HEIGHT
    c.setFont("Times-Italic", 12)
    c.drawString(MARGIN_LEFT, y, "Defendant's Signature")
    
    # Footer
    c.setFont("Times-Roman", 12)
    c.drawString(MARGIN_LEFT, MARGIN_BOTTOM - 20, "(Form UD-7)")
    
    c.save()
    return output_path


if __name__ == "__main__":
    # Test with CIVIL ceremony
    test_data_civil = {
        "plaintiffName": "JANE DOE",
        "defendantName": "JOHN DOE",
        "county": "Orange",
        "indexNumber": "12345/2027",
        "defendantAddress": "123 Main Street, Newburgh, NY 12550",
        "serviceDate": "January 15, 2027",
        "religiousCeremony": False,
        "stateSigned": "New York",
        "countySigned": "Orange",
    }
    
    output = generate_ud7(test_data_civil, "/home/claude/test_ud7_civil.pdf")
    print(f"Generated CIVIL: {output}")
    
    # Test with RELIGIOUS ceremony
    test_data_religious = test_data_civil.copy()
    test_data_religious["religiousCeremony"] = True
    output = generate_ud7(test_data_religious, "/home/claude/test_ud7_religious.pdf")
    print(f"Generated RELIGIOUS: {output}")
