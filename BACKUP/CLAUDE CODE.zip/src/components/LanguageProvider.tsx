"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { usePathname } from "next/navigation";
import { dictionary, Locale } from "../lib/ny-dictionary";
import { njDictionary } from "../lib/nj-dictionary";

type Dictionary = typeof dictionary.en;

interface LanguageContextType {
  lang: Locale;
  setLang: (lang: Locale) => void;
  t: Dictionary;
  state: string;
  setState: (state: string) => void;
}

const defaultContext: LanguageContextType = {
  lang: "en",
  setLang: () => {},
  t: dictionary.en,
  state: "ny",
  setState: () => {},
};

// Registry of state dictionaries
const stateDictionaries: Record<string, Record<Locale, any>> = {
  ny: dictionary,
  nj: njDictionary,
  // nv: nvDictionary, // Add when ready
};

function stateFromPath(path: string): string {
  if (path.startsWith("/nj")) return "nj";
  if (path.startsWith("/nv")) return "nv";
  if (path.startsWith("/ny")) return "ny";
  return "ny";
}

const LanguageContext = createContext<LanguageContextType>(defaultContext);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [lang, setLangState] = useState<Locale>("en");
  const [mounted, setMounted] = useState(false);

  // Reactively derive state from the current pathname
  const state = stateFromPath(pathname);

  // Load saved language on mount
  useEffect(() => {
    const savedLang = localStorage.getItem("divorcegpt-lang") as Locale | null;
    if (savedLang && ["en", "es", "zh", "ko", "ru", "ht"].includes(savedLang)) {
      setLangState(savedLang);
    }
    setMounted(true);
  }, []);

  // Persist language to localStorage
  const setLang = (newLang: Locale) => {
    setLangState(newLang);
    localStorage.setItem("divorcegpt-lang", newLang);
  };

  // setState is now a no-op since state is derived from pathname
  const setState = () => {};

  // Pick the right dictionary: state-specific if available, fallback to NY
  const currentDict = stateDictionaries[state] || dictionary;
  const t = currentDict[lang] || currentDict.en;

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, state, setState }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
